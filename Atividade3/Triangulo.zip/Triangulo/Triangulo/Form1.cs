﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            LadoA.Clear();
            LadoB.Clear();
            LadoC.Clear();

            Tipo.Text = "";
         
        }

        private void BtnConferir_Click(object sender, EventArgs e)
        {
            int ladoA, ladoB, ladoC;

            if (int.TryParse(LadoA.Text, out ladoA) && 
                int.TryParse(LadoB.Text, out ladoB) && 
                int.TryParse(LadoC.Text, out ladoC))
            {
                if ((Math.Abs(ladoB - ladoC) < ladoA && ladoA < (ladoB + ladoC)) &&
                   (Math.Abs(ladoA - ladoC) < ladoB && ladoB < (ladoA + ladoC)) &&
                   (Math.Abs(ladoA - ladoB) < ladoC && ladoC < (ladoA + ladoB)))
                {
                    //Analise: Isosceles, Escaleno, Equilatero;

                    if (ladoA == ladoB && ladoA == ladoC)
                        Tipo.Text = "Equilatero";
                    else if (ladoA == ladoB && ladoA != ladoC)
                        Tipo.Text = "Isosceles";
                    else
                        Tipo.Text = "Escaleno";
                }
                else
                {
                    Tipo.Text = "Não formou";
                }

            }
            else
            {
                MessageBox.Show("Por favor, preencher todos os campos", "Cuidado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
