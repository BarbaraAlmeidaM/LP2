﻿
namespace Triangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LadoA = new System.Windows.Forms.MaskedTextBox();
            this.LadoB = new System.Windows.Forms.MaskedTextBox();
            this.LadoC = new System.Windows.Forms.MaskedTextBox();
            this.Tipo = new System.Windows.Forms.TextBox();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.BtnConferir = new System.Windows.Forms.Button();
            this.BtnFechar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("MV Boli", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label1.Location = new System.Drawing.Point(147, 136);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Lado A:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MV Boli", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label2.Location = new System.Drawing.Point(150, 171);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Lado B:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("MV Boli", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label3.Location = new System.Drawing.Point(149, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Lado C:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("MV Boli", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.MidnightBlue;
            this.label4.Location = new System.Drawing.Point(365, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Tipo:";
            // 
            // LadoA
            // 
            this.LadoA.Location = new System.Drawing.Point(243, 136);
            this.LadoA.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LadoA.Mask = "00";
            this.LadoA.Name = "LadoA";
            this.LadoA.Size = new System.Drawing.Size(116, 25);
            this.LadoA.TabIndex = 4;
            // 
            // LadoB
            // 
            this.LadoB.Location = new System.Drawing.Point(243, 171);
            this.LadoB.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LadoB.Mask = "00";
            this.LadoB.Name = "LadoB";
            this.LadoB.Size = new System.Drawing.Size(116, 25);
            this.LadoB.TabIndex = 5;
            // 
            // LadoC
            // 
            this.LadoC.Location = new System.Drawing.Point(243, 207);
            this.LadoC.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.LadoC.Mask = "00";
            this.LadoC.Name = "LadoC";
            this.LadoC.Size = new System.Drawing.Size(116, 25);
            this.LadoC.TabIndex = 6;
            // 
            // Tipo
            // 
            this.Tipo.Enabled = false;
            this.Tipo.Location = new System.Drawing.Point(433, 170);
            this.Tipo.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Tipo.Name = "Tipo";
            this.Tipo.Size = new System.Drawing.Size(116, 25);
            this.Tipo.TabIndex = 7;
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.BackColor = System.Drawing.Color.LightBlue;
            this.BtnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnLimpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnLimpar.Font = new System.Drawing.Font("MV Boli", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLimpar.Location = new System.Drawing.Point(275, 267);
            this.BtnLimpar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(131, 47);
            this.BtnLimpar.TabIndex = 8;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = false;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // BtnConferir
            // 
            this.BtnConferir.BackColor = System.Drawing.Color.LightBlue;
            this.BtnConferir.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnConferir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnConferir.Font = new System.Drawing.Font("MV Boli", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnConferir.Location = new System.Drawing.Point(126, 267);
            this.BtnConferir.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnConferir.Name = "BtnConferir";
            this.BtnConferir.Size = new System.Drawing.Size(131, 47);
            this.BtnConferir.TabIndex = 9;
            this.BtnConferir.Text = "Conferir";
            this.BtnConferir.UseVisualStyleBackColor = false;
            this.BtnConferir.Click += new System.EventHandler(this.BtnConferir_Click);
            // 
            // BtnFechar
            // 
            this.BtnFechar.BackColor = System.Drawing.Color.LightBlue;
            this.BtnFechar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BtnFechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnFechar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtnFechar.Font = new System.Drawing.Font("MV Boli", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnFechar.Location = new System.Drawing.Point(425, 267);
            this.BtnFechar.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.BtnFechar.Name = "BtnFechar";
            this.BtnFechar.Size = new System.Drawing.Size(132, 47);
            this.BtnFechar.TabIndex = 10;
            this.BtnFechar.Text = "Fechar";
            this.BtnFechar.UseVisualStyleBackColor = false;
            this.BtnFechar.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("MV Boli", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.SteelBlue;
            this.label5.Location = new System.Drawing.Point(148, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(410, 41);
            this.label5.TabIndex = 11;
            this.label5.Text = "TIPOS DE TRIÂNGULOS";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Triangulo.Properties.Resources.Sem_título;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(730, 458);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.BtnFechar);
            this.Controls.Add(this.BtnConferir);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.Tipo);
            this.Controls.Add(this.LadoC);
            this.Controls.Add(this.LadoB);
            this.Controls.Add(this.LadoA);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("MV Boli", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.MaskedTextBox LadoA;
        private System.Windows.Forms.MaskedTextBox LadoB;
        private System.Windows.Forms.MaskedTextBox LadoC;
        private System.Windows.Forms.TextBox Tipo;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button BtnConferir;
        private System.Windows.Forms.Button BtnFechar;
        private System.Windows.Forms.Label label5;
    }
}

