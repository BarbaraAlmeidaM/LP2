﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalculadora
{
    public partial class Form1 : Form
    {
        double Numero1, Numero2, Resultado; public Form1()
        {
            InitializeComponent();
        }


        private void BtmSubtração_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(TextNumero1.Text, out Numero1) || !double.TryParse(TextNumero2.Text, out Numero2))
                MessageBox.Show("Valor Invalido");
            else
            {
                Resultado = Numero1 - Numero2;
                TextResultado.Text = Resultado.ToString("N2");

            }
        }

        private void BtmMultiplicar_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(TextNumero1.Text, out Numero1) || !double.TryParse(TextNumero2.Text, out Numero2))
                MessageBox.Show("Valor Invalido");
            else
            {
                Resultado = Numero1 * Numero2;
                TextResultado.Text = Resultado.ToString("N1");

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            TextNumero1.Clear();
            TextNumero2.Clear();
            TextResultado.Clear();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtmDivisão_Click(object sender, EventArgs e)
        {
            if (double.TryParse(TextNumero1.Text, out Numero1) && double.TryParse(TextNumero2.Text, out Numero2))
                if (Numero2 == 0)
                {
                    MessageBox.Show("Não é possivel dividir por 0");
                }
                else
                {
                    Resultado = Numero1 / Numero2;
                    TextResultado.Text = Resultado.ToString("N2");
                }
            else
                MessageBox.Show("Valores Invalidos");
        }

     

        private void button1_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(TextNumero1.Text, out Numero1) || !double.TryParse(TextNumero2.Text, out Numero2))
                MessageBox.Show("Valor Invalido");
            else
            {
                Resultado = Numero1 + Numero2;
                TextResultado.Text = Resultado.ToString("N2");

            }
        }
    }
}
