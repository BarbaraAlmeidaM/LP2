﻿
namespace PCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TextNumero1 = new System.Windows.Forms.TextBox();
            this.TextNumero2 = new System.Windows.Forms.TextBox();
            this.TextResultado = new System.Windows.Forms.TextBox();
            this.BtmSoma = new System.Windows.Forms.Button();
            this.BtmSubtração = new System.Windows.Forms.Button();
            this.BtmMultiplicar = new System.Windows.Forms.Button();
            this.BtmDivisão = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(157, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Numero 1:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(157, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(109, 30);
            this.label2.TabIndex = 1;
            this.label2.Text = "Numero 2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.AntiqueWhite;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(161, 191);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 30);
            this.label3.TabIndex = 2;
            this.label3.Text = "Resultado:";
            // 
            // TextNumero1
            // 
            this.TextNumero1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextNumero1.Location = new System.Drawing.Point(289, 77);
            this.TextNumero1.Name = "TextNumero1";
            this.TextNumero1.Size = new System.Drawing.Size(241, 31);
            this.TextNumero1.TabIndex = 3;
            // 
            // TextNumero2
            // 
            this.TextNumero2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextNumero2.Location = new System.Drawing.Point(289, 133);
            this.TextNumero2.Name = "TextNumero2";
            this.TextNumero2.Size = new System.Drawing.Size(241, 31);
            this.TextNumero2.TabIndex = 4;
            // 
            // TextResultado
            // 
            this.TextResultado.Enabled = false;
            this.TextResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TextResultado.Location = new System.Drawing.Point(289, 192);
            this.TextResultado.Name = "TextResultado";
            this.TextResultado.Size = new System.Drawing.Size(241, 31);
            this.TextResultado.TabIndex = 5;
            // 
            // BtmSoma
            // 
            this.BtmSoma.BackColor = System.Drawing.Color.AntiqueWhite;
            this.BtmSoma.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtmSoma.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtmSoma.Location = new System.Drawing.Point(289, 243);
            this.BtmSoma.Name = "BtmSoma";
            this.BtmSoma.Size = new System.Drawing.Size(111, 50);
            this.BtmSoma.TabIndex = 6;
            this.BtmSoma.Text = "+";
            this.BtmSoma.UseVisualStyleBackColor = false;
            this.BtmSoma.Click += new System.EventHandler(this.button1_Click);
            // 
            // BtmSubtração
            // 
            this.BtmSubtração.BackColor = System.Drawing.Color.AntiqueWhite;
            this.BtmSubtração.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtmSubtração.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtmSubtração.Location = new System.Drawing.Point(419, 243);
            this.BtmSubtração.Name = "BtmSubtração";
            this.BtmSubtração.Size = new System.Drawing.Size(111, 51);
            this.BtmSubtração.TabIndex = 7;
            this.BtmSubtração.Text = "-";
            this.BtmSubtração.UseVisualStyleBackColor = false;
            this.BtmSubtração.Click += new System.EventHandler(this.BtmSubtração_Click);
            // 
            // BtmMultiplicar
            // 
            this.BtmMultiplicar.BackColor = System.Drawing.Color.AntiqueWhite;
            this.BtmMultiplicar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtmMultiplicar.Font = new System.Drawing.Font("Segoe UI", 26.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtmMultiplicar.Location = new System.Drawing.Point(289, 300);
            this.BtmMultiplicar.Name = "BtmMultiplicar";
            this.BtmMultiplicar.Size = new System.Drawing.Size(111, 51);
            this.BtmMultiplicar.TabIndex = 8;
            this.BtmMultiplicar.Text = "*";
            this.BtmMultiplicar.UseVisualStyleBackColor = false;
            this.BtmMultiplicar.Click += new System.EventHandler(this.BtmMultiplicar_Click);
            // 
            // BtmDivisão
            // 
            this.BtmDivisão.BackColor = System.Drawing.Color.AntiqueWhite;
            this.BtmDivisão.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtmDivisão.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtmDivisão.Location = new System.Drawing.Point(419, 301);
            this.BtmDivisão.Name = "BtmDivisão";
            this.BtmDivisão.Size = new System.Drawing.Size(111, 51);
            this.BtmDivisão.TabIndex = 9;
            this.BtmDivisão.Text = "/";
            this.BtmDivisão.UseVisualStyleBackColor = false;
            this.BtmDivisão.Click += new System.EventHandler(this.BtmDivisão_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.AntiqueWhite;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button5.Location = new System.Drawing.Point(557, 77);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(149, 51);
            this.button5.TabIndex = 10;
            this.button5.Text = "Limpar";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.AntiqueWhite;
            this.button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(557, 170);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(149, 51);
            this.button6.TabIndex = 11;
            this.button6.Text = "Sair";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Mongolian Baiti", 21.75F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(302, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(207, 30);
            this.label4.TabIndex = 12;
            this.label4.Text = "Calculadora BM";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PCalculadora.Properties.Resources.WhatsApp_Image_2021_02_23_at_12_23_17__1_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(857, 506);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.BtmDivisão);
            this.Controls.Add(this.BtmMultiplicar);
            this.Controls.Add(this.BtmSubtração);
            this.Controls.Add(this.BtmSoma);
            this.Controls.Add(this.TextResultado);
            this.Controls.Add(this.TextNumero2);
            this.Controls.Add(this.TextNumero1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Calculadora - BM";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TextNumero1;
        private System.Windows.Forms.TextBox TextNumero2;
        private System.Windows.Forms.TextBox TextResultado;
        private System.Windows.Forms.Button BtmSoma;
        private System.Windows.Forms.Button BtmSubtração;
        private System.Windows.Forms.Button BtmMultiplicar;
        private System.Windows.Forms.Button BtmDivisão;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label4;
    }
}

