﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
           
        private void BtnVerificar_Click(object sender, EventArgs e)
        {

            double SalarioBruto = 0;
            double DescontoINSS = 0;
            double DescontoIR = 0;
            double SalarioFamilia = 0;
            double SalarioLiquido = 0;


            if (mskdNome.Text == string.Empty || mskdNome.Text.Length < 2)
                    MessageBox.Show("Nome Invalido");
            else if (!double.TryParse(mskdSalarioBruto.Text, out SalarioBruto))
                    MessageBox.Show("Salario Invalido");

            else
            {

                if (SalarioBruto <= 800.47)

                {
                    TxtAliquotaINSS.Text = "7.65%";
                    DescontoINSS = 7.65 / 100 * SalarioBruto;
                }

                else if (SalarioBruto <= 1050)
                {
                    TxtAliquotaINSS.Text = "8.65%";
                    DescontoINSS = 8.65 / 100 * SalarioBruto;
                }

                else if (SalarioBruto <= 1400.77)
                {
                    TxtAliquotaINSS.Text = "9.00%";
                    DescontoINSS = 9.00 / 100 * SalarioBruto;
                }

                else if (SalarioBruto <= 2801.56)
                {
                    TxtAliquotaINSS.Text = "11.00%";
                    DescontoINSS = 11.00 / 100 * SalarioBruto;
                }
                else
                {
                    TxtAliquotaINSS.Text = "308.17";
                    DescontoINSS = 308.17;
                }



                if (SalarioBruto <= 1257.12)
                {
                    TxtAliquotaIR.Text = "Isento";
                }
                else if (SalarioBruto <=2512.08)
                {
                    TxtAliquotaIR.Text = "15.00%";
                    DescontoIR = 15.00 / 100 * SalarioBruto;                    
                }
                else
                {
                    TxtAliquotaIR.Text = "27.05%";
                    DescontoIR = 27.05 / 100 * SalarioBruto;
                }

                if (SalarioBruto <= 435.52)
                {
                    SalarioFamilia = Convert.ToInt32(mskdQuantidadeFilhos.Text) * 22.33;
                }
                else if (SalarioBruto <= 652.51)
                {
                    SalarioFamilia = Convert.ToInt32 (mskdQuantidadeFilhos.Text) * 15.74;
                }

                SalarioLiquido = SalarioBruto - DescontoINSS - DescontoIR + SalarioFamilia;

                TxtDescontoINSS.Text = DescontoINSS.ToString("N2");
                TxtDescontoIR.Text = DescontoIR.ToString("N2");
                TxtSalarioFamilia.Text = SalarioFamilia.ToString("N2");
                TxtSalarioLiquido.Text = SalarioLiquido.ToString("N2");


                string stringona = " Os descontos do Salário ";

                if (Feminino.Checked)
                    stringona = stringona +  " Da Sra. ";
                else
                    stringona += " Do Sr.";

                stringona += mskdNome.Text + " que é ";

                if (Casado.Checked)
                    stringona += " Casado(a) e que tem ";
                else
                    stringona += " Solteiro(a) e que tem ";

                stringona += mskdQuantidadeFilhos.Text + " Filho(s) são: ";

                lblMenssagem.Text = stringona;
                lblMenssagem.Visible = true;


            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskdSalarioBruto.Clear();
            TxtAliquotaINSS.Clear();
            TxtAliquotaIR.Clear();
            TxtSalarioFamilia.Clear();
            TxtSalarioLiquido.Clear();
            TxtDescontoINSS.Clear();
            TxtDescontoIR.Clear();
            mskdQuantidadeFilhos.Clear();
            mskdNome.Clear();
            lblMenssagem.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Sexo_Enter(object sender, EventArgs e)
        {

        }

        private void TxtSalarioLiquido_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblSalarioBruto_Click(object sender, EventArgs e)
        {

        }
    }
}
