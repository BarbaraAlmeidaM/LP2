﻿
namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnVerificar = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalarioBruto = new System.Windows.Forms.Label();
            this.lblqtdfilhos = new System.Windows.Forms.Label();
            this.mskdSalarioBruto = new System.Windows.Forms.MaskedTextBox();
            this.lblMenssagem = new System.Windows.Forms.Label();
            this.lblAliquotaINSS = new System.Windows.Forms.Label();
            this.lblAliquotaIR = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIR = new System.Windows.Forms.Label();
            this.TxtAliquotaINSS = new System.Windows.Forms.TextBox();
            this.TxtAliquotaIR = new System.Windows.Forms.TextBox();
            this.TxtSalarioFamilia = new System.Windows.Forms.TextBox();
            this.TxtSalarioLiquido = new System.Windows.Forms.TextBox();
            this.TxtDescontoINSS = new System.Windows.Forms.TextBox();
            this.TxtDescontoIR = new System.Windows.Forms.TextBox();
            this.Sexo = new System.Windows.Forms.GroupBox();
            this.Masculino = new System.Windows.Forms.RadioButton();
            this.Feminino = new System.Windows.Forms.RadioButton();
            this.Compromisso = new System.Windows.Forms.GroupBox();
            this.Solteiro = new System.Windows.Forms.RadioButton();
            this.Casado = new System.Windows.Forms.RadioButton();
            this.btnFechar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.mskdQuantidadeFilhos = new System.Windows.Forms.MaskedTextBox();
            this.mskdNome = new System.Windows.Forms.MaskedTextBox();
            this.BM = new System.Windows.Forms.Label();
            this.Sexo.SuspendLayout();
            this.Compromisso.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnVerificar
            // 
            this.BtnVerificar.BackColor = System.Drawing.Color.Gainsboro;
            this.BtnVerificar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BtnVerificar.ForeColor = System.Drawing.Color.Black;
            this.BtnVerificar.Location = new System.Drawing.Point(221, 147);
            this.BtnVerificar.Name = "BtnVerificar";
            this.BtnVerificar.Size = new System.Drawing.Size(118, 41);
            this.BtnVerificar.TabIndex = 0;
            this.BtnVerificar.Text = "Verificar Desconto";
            this.BtnVerificar.UseVisualStyleBackColor = false;
            this.BtnVerificar.Click += new System.EventHandler(this.BtnVerificar_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.BackColor = System.Drawing.Color.Transparent;
            this.lblNome.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.ForeColor = System.Drawing.Color.White;
            this.lblNome.Location = new System.Drawing.Point(56, 72);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(142, 21);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome Funcionario:";
            // 
            // lblSalarioBruto
            // 
            this.lblSalarioBruto.AutoSize = true;
            this.lblSalarioBruto.BackColor = System.Drawing.Color.Transparent;
            this.lblSalarioBruto.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioBruto.ForeColor = System.Drawing.Color.White;
            this.lblSalarioBruto.Location = new System.Drawing.Point(55, 94);
            this.lblSalarioBruto.Name = "lblSalarioBruto";
            this.lblSalarioBruto.Size = new System.Drawing.Size(103, 21);
            this.lblSalarioBruto.TabIndex = 2;
            this.lblSalarioBruto.Text = "Salário Bruto:";
            this.lblSalarioBruto.Click += new System.EventHandler(this.lblSalarioBruto_Click);
            // 
            // lblqtdfilhos
            // 
            this.lblqtdfilhos.AutoSize = true;
            this.lblqtdfilhos.BackColor = System.Drawing.Color.Transparent;
            this.lblqtdfilhos.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqtdfilhos.ForeColor = System.Drawing.Color.White;
            this.lblqtdfilhos.Location = new System.Drawing.Point(55, 118);
            this.lblqtdfilhos.Name = "lblqtdfilhos";
            this.lblqtdfilhos.Size = new System.Drawing.Size(160, 21);
            this.lblqtdfilhos.TabIndex = 3;
            this.lblqtdfilhos.Text = "Quantidade de Filhos:";
            // 
            // mskdSalarioBruto
            // 
            this.mskdSalarioBruto.Location = new System.Drawing.Point(221, 95);
            this.mskdSalarioBruto.Mask = "00000.00";
            this.mskdSalarioBruto.Name = "mskdSalarioBruto";
            this.mskdSalarioBruto.Size = new System.Drawing.Size(118, 20);
            this.mskdSalarioBruto.TabIndex = 4;
            // 
            // lblMenssagem
            // 
            this.lblMenssagem.AutoSize = true;
            this.lblMenssagem.BackColor = System.Drawing.Color.Transparent;
            this.lblMenssagem.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMenssagem.ForeColor = System.Drawing.Color.Transparent;
            this.lblMenssagem.Location = new System.Drawing.Point(60, 194);
            this.lblMenssagem.MaximumSize = new System.Drawing.Size(300, 0);
            this.lblMenssagem.Name = "lblMenssagem";
            this.lblMenssagem.Size = new System.Drawing.Size(79, 21);
            this.lblMenssagem.TabIndex = 7;
            this.lblMenssagem.Text = "Resultado";
            // 
            // lblAliquotaINSS
            // 
            this.lblAliquotaINSS.AutoSize = true;
            this.lblAliquotaINSS.BackColor = System.Drawing.Color.Transparent;
            this.lblAliquotaINSS.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaINSS.ForeColor = System.Drawing.Color.White;
            this.lblAliquotaINSS.Location = new System.Drawing.Point(60, 262);
            this.lblAliquotaINSS.Name = "lblAliquotaINSS";
            this.lblAliquotaINSS.Size = new System.Drawing.Size(106, 21);
            this.lblAliquotaINSS.TabIndex = 8;
            this.lblAliquotaINSS.Text = "Aliquota INSS";
            // 
            // lblAliquotaIR
            // 
            this.lblAliquotaIR.AutoSize = true;
            this.lblAliquotaIR.BackColor = System.Drawing.Color.Transparent;
            this.lblAliquotaIR.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAliquotaIR.ForeColor = System.Drawing.Color.White;
            this.lblAliquotaIR.Location = new System.Drawing.Point(62, 294);
            this.lblAliquotaIR.Name = "lblAliquotaIR";
            this.lblAliquotaIR.Size = new System.Drawing.Size(86, 21);
            this.lblAliquotaIR.TabIndex = 9;
            this.lblAliquotaIR.Text = "Aliquota IR";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.BackColor = System.Drawing.Color.Transparent;
            this.lblSalarioFamilia.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFamilia.ForeColor = System.Drawing.Color.White;
            this.lblSalarioFamilia.Location = new System.Drawing.Point(62, 330);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(112, 21);
            this.lblSalarioFamilia.TabIndex = 10;
            this.lblSalarioFamilia.Text = "Salario Familia";
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.BackColor = System.Drawing.Color.Transparent;
            this.lblSalarioLiquido.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioLiquido.ForeColor = System.Drawing.Color.White;
            this.lblSalarioLiquido.Location = new System.Drawing.Point(62, 362);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(114, 21);
            this.lblSalarioLiquido.TabIndex = 11;
            this.lblSalarioLiquido.Text = "Salario Liquido";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.BackColor = System.Drawing.Color.Transparent;
            this.lblDescontoINSS.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoINSS.ForeColor = System.Drawing.Color.White;
            this.lblDescontoINSS.Location = new System.Drawing.Point(299, 261);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(113, 21);
            this.lblDescontoINSS.TabIndex = 12;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIR
            // 
            this.lblDescontoIR.AutoSize = true;
            this.lblDescontoIR.BackColor = System.Drawing.Color.Transparent;
            this.lblDescontoIR.Font = new System.Drawing.Font("Segoe UI Symbol", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Italic | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoIR.ForeColor = System.Drawing.Color.White;
            this.lblDescontoIR.Location = new System.Drawing.Point(299, 301);
            this.lblDescontoIR.Name = "lblDescontoIR";
            this.lblDescontoIR.Size = new System.Drawing.Size(93, 21);
            this.lblDescontoIR.TabIndex = 13;
            this.lblDescontoIR.Text = "Desconto IR";
            // 
            // TxtAliquotaINSS
            // 
            this.TxtAliquotaINSS.Enabled = false;
            this.TxtAliquotaINSS.Location = new System.Drawing.Point(172, 261);
            this.TxtAliquotaINSS.Name = "TxtAliquotaINSS";
            this.TxtAliquotaINSS.Size = new System.Drawing.Size(121, 20);
            this.TxtAliquotaINSS.TabIndex = 14;
            // 
            // TxtAliquotaIR
            // 
            this.TxtAliquotaIR.Enabled = false;
            this.TxtAliquotaIR.Location = new System.Drawing.Point(172, 294);
            this.TxtAliquotaIR.Name = "TxtAliquotaIR";
            this.TxtAliquotaIR.Size = new System.Drawing.Size(121, 20);
            this.TxtAliquotaIR.TabIndex = 15;
            // 
            // TxtSalarioFamilia
            // 
            this.TxtSalarioFamilia.Enabled = false;
            this.TxtSalarioFamilia.Location = new System.Drawing.Point(172, 330);
            this.TxtSalarioFamilia.Name = "TxtSalarioFamilia";
            this.TxtSalarioFamilia.Size = new System.Drawing.Size(121, 20);
            this.TxtSalarioFamilia.TabIndex = 16;
            // 
            // TxtSalarioLiquido
            // 
            this.TxtSalarioLiquido.Enabled = false;
            this.TxtSalarioLiquido.Location = new System.Drawing.Point(172, 365);
            this.TxtSalarioLiquido.Name = "TxtSalarioLiquido";
            this.TxtSalarioLiquido.Size = new System.Drawing.Size(121, 20);
            this.TxtSalarioLiquido.TabIndex = 17;
            this.TxtSalarioLiquido.TextChanged += new System.EventHandler(this.TxtSalarioLiquido_TextChanged);
            // 
            // TxtDescontoINSS
            // 
            this.TxtDescontoINSS.Enabled = false;
            this.TxtDescontoINSS.Location = new System.Drawing.Point(421, 262);
            this.TxtDescontoINSS.Name = "TxtDescontoINSS";
            this.TxtDescontoINSS.Size = new System.Drawing.Size(118, 20);
            this.TxtDescontoINSS.TabIndex = 18;
            // 
            // TxtDescontoIR
            // 
            this.TxtDescontoIR.Enabled = false;
            this.TxtDescontoIR.Location = new System.Drawing.Point(421, 301);
            this.TxtDescontoIR.Name = "TxtDescontoIR";
            this.TxtDescontoIR.Size = new System.Drawing.Size(118, 20);
            this.TxtDescontoIR.TabIndex = 19;
            // 
            // Sexo
            // 
            this.Sexo.BackColor = System.Drawing.Color.Transparent;
            this.Sexo.Controls.Add(this.Masculino);
            this.Sexo.Controls.Add(this.Feminino);
            this.Sexo.ForeColor = System.Drawing.Color.White;
            this.Sexo.Location = new System.Drawing.Point(360, 72);
            this.Sexo.Name = "Sexo";
            this.Sexo.Size = new System.Drawing.Size(200, 85);
            this.Sexo.TabIndex = 20;
            this.Sexo.TabStop = false;
            this.Sexo.Text = "Sexo";
            this.Sexo.Enter += new System.EventHandler(this.Sexo_Enter);
            // 
            // Masculino
            // 
            this.Masculino.AutoSize = true;
            this.Masculino.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Masculino.Location = new System.Drawing.Point(7, 61);
            this.Masculino.Name = "Masculino";
            this.Masculino.Size = new System.Drawing.Size(73, 17);
            this.Masculino.TabIndex = 1;
            this.Masculino.Text = "Masculino";
            this.Masculino.UseVisualStyleBackColor = true;
            // 
            // Feminino
            // 
            this.Feminino.AutoSize = true;
            this.Feminino.Checked = true;
            this.Feminino.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Feminino.Location = new System.Drawing.Point(7, 35);
            this.Feminino.Name = "Feminino";
            this.Feminino.Size = new System.Drawing.Size(67, 17);
            this.Feminino.TabIndex = 0;
            this.Feminino.TabStop = true;
            this.Feminino.Text = "Feminino";
            this.Feminino.UseVisualStyleBackColor = true;
            // 
            // Compromisso
            // 
            this.Compromisso.BackColor = System.Drawing.Color.Transparent;
            this.Compromisso.Controls.Add(this.Solteiro);
            this.Compromisso.Controls.Add(this.Casado);
            this.Compromisso.ForeColor = System.Drawing.Color.White;
            this.Compromisso.Location = new System.Drawing.Point(360, 163);
            this.Compromisso.Name = "Compromisso";
            this.Compromisso.Size = new System.Drawing.Size(200, 89);
            this.Compromisso.TabIndex = 21;
            this.Compromisso.TabStop = false;
            this.Compromisso.Text = "Estado Civil";
            // 
            // Solteiro
            // 
            this.Solteiro.AutoSize = true;
            this.Solteiro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Solteiro.Location = new System.Drawing.Point(7, 58);
            this.Solteiro.Name = "Solteiro";
            this.Solteiro.Size = new System.Drawing.Size(72, 17);
            this.Solteiro.TabIndex = 2;
            this.Solteiro.Text = "Solteiro(a)";
            this.Solteiro.UseVisualStyleBackColor = true;
            // 
            // Casado
            // 
            this.Casado.AutoSize = true;
            this.Casado.Checked = true;
            this.Casado.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Casado.Location = new System.Drawing.Point(6, 35);
            this.Casado.Name = "Casado";
            this.Casado.Size = new System.Drawing.Size(73, 17);
            this.Casado.TabIndex = 1;
            this.Casado.TabStop = true;
            this.Casado.Text = "Casado(a)";
            this.Casado.UseVisualStyleBackColor = true;
            // 
            // btnFechar
            // 
            this.btnFechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFechar.Location = new System.Drawing.Point(333, 433);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(178, 31);
            this.btnFechar.TabIndex = 23;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLimpar.Location = new System.Drawing.Point(128, 433);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(178, 31);
            this.btnLimpar.TabIndex = 24;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // mskdQuantidadeFilhos
            // 
            this.mskdQuantidadeFilhos.Location = new System.Drawing.Point(221, 121);
            this.mskdQuantidadeFilhos.Mask = "00";
            this.mskdQuantidadeFilhos.Name = "mskdQuantidadeFilhos";
            this.mskdQuantidadeFilhos.Size = new System.Drawing.Size(118, 20);
            this.mskdQuantidadeFilhos.TabIndex = 25;
            // 
            // mskdNome
            // 
            this.mskdNome.HidePromptOnLeave = true;
            this.mskdNome.Location = new System.Drawing.Point(221, 72);
            this.mskdNome.Mask = "LLLLLLLLLLLLLLL";
            this.mskdNome.Name = "mskdNome";
            this.mskdNome.Size = new System.Drawing.Size(118, 20);
            this.mskdNome.TabIndex = 26;
            // 
            // BM
            // 
            this.BM.AutoSize = true;
            this.BM.BackColor = System.Drawing.Color.Transparent;
            this.BM.Font = new System.Drawing.Font("Segoe UI Symbol", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BM.ForeColor = System.Drawing.Color.White;
            this.BM.Location = new System.Drawing.Point(259, 9);
            this.BM.Name = "BM";
            this.BM.Size = new System.Drawing.Size(69, 45);
            this.BM.TabIndex = 27;
            this.BM.Text = "BM";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PSalario.Properties.Resources.pngtree_ppt_minimalistic_geometric_background_backgroundppt_template_backgroundsimplecool_image_54790;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(679, 486);
            this.Controls.Add(this.BM);
            this.Controls.Add(this.mskdNome);
            this.Controls.Add(this.mskdQuantidadeFilhos);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.Compromisso);
            this.Controls.Add(this.Sexo);
            this.Controls.Add(this.TxtDescontoIR);
            this.Controls.Add(this.TxtDescontoINSS);
            this.Controls.Add(this.TxtSalarioLiquido);
            this.Controls.Add(this.TxtSalarioFamilia);
            this.Controls.Add(this.TxtAliquotaIR);
            this.Controls.Add(this.TxtAliquotaINSS);
            this.Controls.Add(this.lblDescontoIR);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblAliquotaIR);
            this.Controls.Add(this.lblAliquotaINSS);
            this.Controls.Add(this.lblMenssagem);
            this.Controls.Add(this.mskdSalarioBruto);
            this.Controls.Add(this.lblqtdfilhos);
            this.Controls.Add(this.lblSalarioBruto);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.BtnVerificar);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Salario";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Sexo.ResumeLayout(false);
            this.Sexo.PerformLayout();
            this.Compromisso.ResumeLayout(false);
            this.Compromisso.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnVerificar;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalarioBruto;
        private System.Windows.Forms.Label lblqtdfilhos;
        private System.Windows.Forms.MaskedTextBox mskdSalarioBruto;
        private System.Windows.Forms.Label lblMenssagem;
        private System.Windows.Forms.Label lblAliquotaINSS;
        private System.Windows.Forms.Label lblAliquotaIR;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIR;
        private System.Windows.Forms.TextBox TxtAliquotaINSS;
        private System.Windows.Forms.TextBox TxtAliquotaIR;
        private System.Windows.Forms.TextBox TxtSalarioFamilia;
        private System.Windows.Forms.TextBox TxtSalarioLiquido;
        private System.Windows.Forms.TextBox TxtDescontoINSS;
        private System.Windows.Forms.TextBox TxtDescontoIR;
        private System.Windows.Forms.GroupBox Sexo;
        private System.Windows.Forms.RadioButton Masculino;
        private System.Windows.Forms.RadioButton Feminino;
        private System.Windows.Forms.GroupBox Compromisso;
        private System.Windows.Forms.RadioButton Solteiro;
        private System.Windows.Forms.RadioButton Casado;
        private System.Windows.Forms.Button btnFechar;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.MaskedTextBox mskdQuantidadeFilhos;
        private System.Windows.Forms.MaskedTextBox mskdNome;
        private System.Windows.Forms.Label BM;
    }
}

