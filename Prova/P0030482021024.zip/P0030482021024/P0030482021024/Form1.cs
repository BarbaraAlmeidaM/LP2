﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;

namespace P0030482021024
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            double[,] Valores = new double[4, 4];
            double[] TotalMes = new double[4];
            string Valor;
            double TotalDeMeses = 0;

            for (int b = 0; b < 4; b++)
            {
                for (int m = 0; m < 4; m++)
                {
                    Valor = Interaction.InputBox("Digite o valor da semana " + (m + 1) + " Do Mês: " + (m + 1), "Entrada de dados:");
                    if (Valor == "")
                    {
                        MessageBox.Show("Este campo está vazio, por favor preencher tudo.");
                        m--;
                    }
                    else if (double.TryParse(Valor, out Valores[b, m]))
                    {
                        double.TryParse(Valor, out Valores[b, m]);
                    }
                    else
                    {
                        MessageBox.Show("Por favor, digite apenas números!");
                        m--;
                    }
                }
            }

            for (int b = 0; b < 4; b++)
            {
                for (int m = 0; m < 4; m++)
                {
                    TotalMes[b] = TotalMes[b] + Valores[b, m];
                }
                TotalDeMeses = TotalDeMeses + TotalMes[b];
            }

            for (int b = 0; b < 4; b++)
            {
                for (int m = 0; m < 4; m++)
                {
                    lsbResultados.Items.Add("Total do Mês: " + (b + 1) + " Semana: " + (m + 1) + ": R$" + Valores[b, m].ToString("N2"));
                }
                lsbResultados.Items.Add(">>Total Mês: " + TotalMes[b].ToString("C2"));
            }
            lsbResultados.Items.Add("Total Geral: " + TotalDeMeses.ToString("C2"));

            lsbResultados.Items.Add("*******************");

            lsbResultados.Items.Add("Fim do programa");

            lsbResultados.Items.Add("*******************");

            lsbResultados.Items.Add("Ps: Me dá 10");
        }

    }
    
}
