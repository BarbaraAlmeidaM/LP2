﻿
namespace OPesoIdeal
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Altura = new System.Windows.Forms.MaskedTextBox();
            this.Peso = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBoxResultado = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Masculino = new System.Windows.Forms.RadioButton();
            this.Feminino = new System.Windows.Forms.RadioButton();
            this.button1Calcular = new System.Windows.Forms.Button();
            this.button2Limpar = new System.Windows.Forms.Button();
            this.button3Fechar = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.PesoIdeal = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(181, 146);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Altura:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(190, 184);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Peso:";
            // 
            // Altura
            // 
            this.Altura.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Altura.Location = new System.Drawing.Point(262, 135);
            this.Altura.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Altura.Mask = "0.00";
            this.Altura.Name = "Altura";
            this.Altura.Size = new System.Drawing.Size(159, 31);
            this.Altura.TabIndex = 2;
            // 
            // Peso
            // 
            this.Peso.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Peso.Location = new System.Drawing.Point(262, 181);
            this.Peso.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Peso.Mask = "000.00";
            this.Peso.Name = "Peso";
            this.Peso.Size = new System.Drawing.Size(159, 31);
            this.Peso.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(145, 260);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(119, 20);
            this.label3.TabIndex = 4;
            this.label3.Text = "Resultado:";
            // 
            // textBoxResultado
            // 
            this.textBoxResultado.Enabled = false;
            this.textBoxResultado.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxResultado.Location = new System.Drawing.Point(262, 257);
            this.textBoxResultado.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.textBoxResultado.Name = "textBoxResultado";
            this.textBoxResultado.Size = new System.Drawing.Size(159, 31);
            this.textBoxResultado.TabIndex = 5;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.Masculino);
            this.groupBox1.Controls.Add(this.Feminino);
            this.groupBox1.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(435, 116);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.groupBox1.Size = new System.Drawing.Size(266, 111);
            this.groupBox1.TabIndex = 6;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo";
            // 
            // Masculino
            // 
            this.Masculino.AutoSize = true;
            this.Masculino.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Masculino.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Masculino.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.Masculino.Location = new System.Drawing.Point(6, 57);
            this.Masculino.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Masculino.Name = "Masculino";
            this.Masculino.Size = new System.Drawing.Size(126, 23);
            this.Masculino.TabIndex = 1;
            this.Masculino.Text = "Masculino";
            this.Masculino.UseVisualStyleBackColor = true;
            // 
            // Feminino
            // 
            this.Feminino.AutoSize = true;
            this.Feminino.Checked = true;
            this.Feminino.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Feminino.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Feminino.ForeColor = System.Drawing.Color.Crimson;
            this.Feminino.Location = new System.Drawing.Point(6, 24);
            this.Feminino.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.Feminino.Name = "Feminino";
            this.Feminino.Size = new System.Drawing.Size(115, 23);
            this.Feminino.TabIndex = 0;
            this.Feminino.TabStop = true;
            this.Feminino.Text = "Feminino";
            this.Feminino.UseVisualStyleBackColor = true;
            // 
            // button1Calcular
            // 
            this.button1Calcular.BackColor = System.Drawing.SystemColors.Control;
            this.button1Calcular.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1Calcular.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1Calcular.ForeColor = System.Drawing.Color.Maroon;
            this.button1Calcular.Location = new System.Drawing.Point(296, 220);
            this.button1Calcular.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button1Calcular.Name = "button1Calcular";
            this.button1Calcular.Size = new System.Drawing.Size(99, 27);
            this.button1Calcular.TabIndex = 7;
            this.button1Calcular.Text = "Calcular";
            this.button1Calcular.UseVisualStyleBackColor = false;
            this.button1Calcular.Click += new System.EventHandler(this.button1Calcular_Click);
            // 
            // button2Limpar
            // 
            this.button2Limpar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2Limpar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2Limpar.ForeColor = System.Drawing.Color.Maroon;
            this.button2Limpar.Location = new System.Drawing.Point(296, 346);
            this.button2Limpar.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button2Limpar.Name = "button2Limpar";
            this.button2Limpar.Size = new System.Drawing.Size(99, 27);
            this.button2Limpar.TabIndex = 8;
            this.button2Limpar.Text = "Limpar";
            this.button2Limpar.UseVisualStyleBackColor = true;
            this.button2Limpar.Click += new System.EventHandler(this.button2Limpar_Click);
            // 
            // button3Fechar
            // 
            this.button3Fechar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3Fechar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3Fechar.ForeColor = System.Drawing.Color.Maroon;
            this.button3Fechar.Location = new System.Drawing.Point(296, 383);
            this.button3Fechar.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.button3Fechar.Name = "button3Fechar";
            this.button3Fechar.Size = new System.Drawing.Size(99, 27);
            this.button3Fechar.TabIndex = 9;
            this.button3Fechar.Text = "Fechar";
            this.button3Fechar.UseVisualStyleBackColor = true;
            this.button3Fechar.Click += new System.EventHandler(this.button3Fechar_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(146, 309);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(130, 19);
            this.label4.TabIndex = 10;
            this.label4.Text = "Peso Ideal:";
            // 
            // PesoIdeal
            // 
            this.PesoIdeal.Enabled = false;
            this.PesoIdeal.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PesoIdeal.Location = new System.Drawing.Point(262, 305);
            this.PesoIdeal.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.PesoIdeal.Name = "PesoIdeal";
            this.PesoIdeal.Size = new System.Drawing.Size(159, 31);
            this.PesoIdeal.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 48F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Crimson;
            this.label5.Location = new System.Drawing.Point(174, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(358, 64);
            this.label5.TabIndex = 12;
            this.label5.Text = "Peso Ideal";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::OPesoIdeal.Properties.Resources.Sem_título1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(730, 510);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.PesoIdeal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button3Fechar);
            this.Controls.Add(this.button2Limpar);
            this.Controls.Add(this.button1Calcular);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.textBoxResultado);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Peso);
            this.Controls.Add(this.Altura);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("MingLiU_HKSCS-ExtB", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox Altura;
        private System.Windows.Forms.MaskedTextBox Peso;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBoxResultado;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Masculino;
        private System.Windows.Forms.RadioButton Feminino;
        private System.Windows.Forms.Button button1Calcular;
        private System.Windows.Forms.Button button2Limpar;
        private System.Windows.Forms.Button button3Fechar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox PesoIdeal;
        private System.Windows.Forms.Label label5;
    }
}

