﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OPesoIdeal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2Limpar_Click(object sender, EventArgs e)
        {
            this.Altura.Clear();
            this.Peso.Clear();
            this.textBoxResultado.Clear();

            this.PesoIdeal.Clear();

        }

        private void button1Calcular_Click(object sender, EventArgs e)
        {
            double peso, altura, resultado=0;

            if (double.TryParse(Altura.Text, out altura) && double.TryParse(Peso.Text, out peso))
            {

                if (Masculino.Checked)
                {
                    resultado = (72.7 * altura) - 58;
                }
                else if (Feminino.Checked)
                {
                    resultado = (62.1 * altura) - 44.7; 
                }

                resultado = Math.Round(resultado, 2);

                if (peso > resultado)
                {
                    //MessageBox.Show("Acima do Peso!");

                    this.textBoxResultado.Text = "Acima do Peso!";
                }
                else if (peso == resultado)
                {
                    //MessageBox.Show("Peso ideal!");

                    this.textBoxResultado.Text = "Peso Ideal!";
                }
                else
                {
                    //MessageBox.Show("Abaixo do Peso");

                    this.textBoxResultado.Text = "Abaixo do Peso";
                }

                    this.PesoIdeal.Text = resultado.ToString();

            }   
            
            else
            {
                MessageBox.Show("Prencha tudo!", "Cuidado", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                //              Mensagem          Titulo    Botão                 Icone
               
            }
        }

        private void button3Fechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
