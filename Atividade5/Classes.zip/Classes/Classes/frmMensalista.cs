﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classes
{
    public partial class frmMensalista : Form
    {
        public frmMensalista()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void btnInstMensalista_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista();

            objMensalista.Matricula = Convert.ToInt32(TxtMatricula.Text);
            objMensalista.NomeEmpregado = TxtNome.Text;
            objMensalista.DataEntradaEmpresa = Convert.ToDateTime(TxtDataEntrada.Text);
            objMensalista.SalarioMensal = Convert.ToDouble(TxtSalarioMensal.Text);

        }

        private void btnInstanciarParametros_Click(object sender, EventArgs e)
        {
            Mensalista objMensalista = new Mensalista(Convert.ToInt32(TxtMatricula.Text),
                TxtNome.Text, Convert.ToDateTime(TxtDataEntrada.Text), Convert.ToDouble(TxtSalarioMensal.Text));

            MessageBox.Show("Matricula=" + objMensalista.Matricula + "\n" +
                "Nome=" + objMensalista.NomeEmpregado + "\n" +
                 "DataEntrada:" + objMensalista.DataEntradaEmpresa.ToShortDateString() +
                 "\n" +
                 "Salario Bruto=" + objMensalista.SalarioBruto().ToString("N2")+ "\n" +
                "Tempo Empresa (dias): " + objMensalista.TempoTrabalho());



        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtMatricula.Clear();
            TxtNome.Clear();
            TxtSalarioMensal.Clear();
            TxtDataEntrada.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
