﻿
namespace Classes
{
    partial class fmrHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TxtHMatricula = new System.Windows.Forms.TextBox();
            this.TxtHNome = new System.Windows.Forms.TextBox();
            this.TxtHSalarioPorHora = new System.Windows.Forms.TextBox();
            this.TxtHNumeroDeHoras = new System.Windows.Forms.TextBox();
            this.TxtHDataEntradaNaEmpresa = new System.Windows.Forms.TextBox();
            this.TxtHFaltas = new System.Windows.Forms.TextBox();
            this.BtnInsHorista = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.BackColor = System.Drawing.Color.Transparent;
            this.lblMatricula.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.ForeColor = System.Drawing.Color.White;
            this.lblMatricula.Location = new System.Drawing.Point(186, 123);
            this.lblMatricula.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(96, 25);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matricula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(186, 159);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Transparent;
            this.label3.Location = new System.Drawing.Point(186, 187);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Salario por Hora";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(186, 219);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Numero de Horas";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(186, 254);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(240, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Data Entrada na Empresa";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Yu Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(186, 287);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Dias de Faltas";
            // 
            // TxtHMatricula
            // 
            this.TxtHMatricula.Location = new System.Drawing.Point(451, 118);
            this.TxtHMatricula.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtHMatricula.Name = "TxtHMatricula";
            this.TxtHMatricula.Size = new System.Drawing.Size(201, 22);
            this.TxtHMatricula.TabIndex = 6;
            // 
            // TxtHNome
            // 
            this.TxtHNome.Location = new System.Drawing.Point(451, 154);
            this.TxtHNome.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtHNome.Name = "TxtHNome";
            this.TxtHNome.Size = new System.Drawing.Size(201, 22);
            this.TxtHNome.TabIndex = 7;
            // 
            // TxtHSalarioPorHora
            // 
            this.TxtHSalarioPorHora.Location = new System.Drawing.Point(451, 186);
            this.TxtHSalarioPorHora.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtHSalarioPorHora.Name = "TxtHSalarioPorHora";
            this.TxtHSalarioPorHora.Size = new System.Drawing.Size(201, 22);
            this.TxtHSalarioPorHora.TabIndex = 8;
            // 
            // TxtHNumeroDeHoras
            // 
            this.TxtHNumeroDeHoras.Location = new System.Drawing.Point(451, 219);
            this.TxtHNumeroDeHoras.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtHNumeroDeHoras.Name = "TxtHNumeroDeHoras";
            this.TxtHNumeroDeHoras.Size = new System.Drawing.Size(201, 22);
            this.TxtHNumeroDeHoras.TabIndex = 9;
            // 
            // TxtHDataEntradaNaEmpresa
            // 
            this.TxtHDataEntradaNaEmpresa.Location = new System.Drawing.Point(451, 254);
            this.TxtHDataEntradaNaEmpresa.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtHDataEntradaNaEmpresa.Name = "TxtHDataEntradaNaEmpresa";
            this.TxtHDataEntradaNaEmpresa.Size = new System.Drawing.Size(201, 22);
            this.TxtHDataEntradaNaEmpresa.TabIndex = 10;
            // 
            // TxtHFaltas
            // 
            this.TxtHFaltas.Location = new System.Drawing.Point(451, 287);
            this.TxtHFaltas.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.TxtHFaltas.Name = "TxtHFaltas";
            this.TxtHFaltas.Size = new System.Drawing.Size(201, 22);
            this.TxtHFaltas.TabIndex = 11;
            // 
            // BtnInsHorista
            // 
            this.BtnInsHorista.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnInsHorista.Location = new System.Drawing.Point(451, 315);
            this.BtnInsHorista.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnInsHorista.Name = "BtnInsHorista";
            this.BtnInsHorista.Size = new System.Drawing.Size(201, 43);
            this.BtnInsHorista.TabIndex = 12;
            this.BtnInsHorista.Text = "Instanciar Horista";
            this.BtnInsHorista.UseVisualStyleBackColor = true;
            this.BtnInsHorista.Click += new System.EventHandler(this.BtnInsHorista_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(461, 65);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 50);
            this.label1.TabIndex = 13;
            this.label1.Text = "HORISTA";
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.BtnLimpar.Location = new System.Drawing.Point(191, 380);
            this.BtnLimpar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(201, 43);
            this.BtnLimpar.TabIndex = 14;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.btnFechar.Location = new System.Drawing.Point(451, 380);
            this.btnFechar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(201, 43);
            this.btnFechar.TabIndex = 15;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // fmrHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Classes.Properties.Resources.pngtree_ppt_minimalistic_geometric_background_backgroundppt_template_backgroundsimplecool_image_54790;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(794, 440);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BtnInsHorista);
            this.Controls.Add(this.TxtHFaltas);
            this.Controls.Add(this.TxtHDataEntradaNaEmpresa);
            this.Controls.Add(this.TxtHNumeroDeHoras);
            this.Controls.Add(this.TxtHSalarioPorHora);
            this.Controls.Add(this.TxtHNome);
            this.Controls.Add(this.TxtHMatricula);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblMatricula);
            this.Font = new System.Drawing.Font("Segoe UI Symbol", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "fmrHorista";
            this.Text = "fmrHorista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TxtHMatricula;
        private System.Windows.Forms.TextBox TxtHNome;
        private System.Windows.Forms.TextBox TxtHSalarioPorHora;
        private System.Windows.Forms.TextBox TxtHNumeroDeHoras;
        private System.Windows.Forms.TextBox TxtHDataEntradaNaEmpresa;
        private System.Windows.Forms.TextBox TxtHFaltas;
        private System.Windows.Forms.Button BtnInsHorista;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button btnFechar;
    }
}