﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Classes
{
    public partial class fmrHorista : Form
    {
        public fmrHorista()
        {
            InitializeComponent();
        }

        private void BtnInsHorista_Click(object sender, EventArgs e)
        {
            //Empregado ObjEmpregado = new Empregado();
            Horista ObjHorista = new Horista();

            ObjHorista.NomeEmpregado = TxtHNome.Text;
            ObjHorista.Matricula = Convert.ToInt32(TxtHMatricula.Text);
            ObjHorista.SalarioHora = Convert.ToDouble(TxtHSalarioPorHora.Text);
            ObjHorista.NumeroHora = Convert.ToDouble(TxtHNumeroDeHoras.Text);
            ObjHorista.DataEntradaEmpresa = Convert.ToDateTime(TxtHDataEntradaNaEmpresa.Text);
            ObjHorista.DiasFalta = Convert.ToInt32(TxtHFaltas.Text);

            MessageBox.Show("Nome=" + ObjHorista.NomeEmpregado + "\n" +
                "Matricula=" + ObjHorista.Matricula + "\n" +
                "Tempo Trabalho:" + ObjHorista.TempoTrabalho().ToString() +
                "\n" + "Salario=" + ObjHorista.SalarioBruto().ToString("N2"));


        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtHMatricula.Clear();
            TxtHNome.Clear();
            TxtHSalarioPorHora.Clear();
            TxtHNumeroDeHoras.Clear();
            TxtHDataEntradaNaEmpresa.Clear();
            TxtHFaltas.Clear();
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
