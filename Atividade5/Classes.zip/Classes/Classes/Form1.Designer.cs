﻿
namespace Classes
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMensalista = new System.Windows.Forms.Button();
            this.BtnHorista = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMensalista
            // 
            this.btnMensalista.BackColor = System.Drawing.Color.Gainsboro;
            this.btnMensalista.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.btnMensalista.Location = new System.Drawing.Point(294, 132);
            this.btnMensalista.Name = "btnMensalista";
            this.btnMensalista.Size = new System.Drawing.Size(181, 64);
            this.btnMensalista.TabIndex = 0;
            this.btnMensalista.Text = "Mensalista";
            this.btnMensalista.UseVisualStyleBackColor = false;
            this.btnMensalista.Click += new System.EventHandler(this.btnMensalista_Click);
            // 
            // BtnHorista
            // 
            this.BtnHorista.BackColor = System.Drawing.Color.Transparent;
            this.BtnHorista.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.BtnHorista.Location = new System.Drawing.Point(294, 202);
            this.BtnHorista.Name = "BtnHorista";
            this.BtnHorista.Size = new System.Drawing.Size(181, 64);
            this.BtnHorista.TabIndex = 1;
            this.BtnHorista.Text = "Horista";
            this.BtnHorista.UseVisualStyleBackColor = false;
            this.BtnHorista.Click += new System.EventHandler(this.BtnHorista_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnFechar.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.btnFechar.Location = new System.Drawing.Point(294, 272);
            this.btnFechar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(181, 64);
            this.btnFechar.TabIndex = 16;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Classes.Properties.Resources.pngtree_ppt_minimalistic_geometric_background_backgroundppt_template_backgroundsimplecool_image_54790;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(794, 440);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.BtnHorista);
            this.Controls.Add(this.btnMensalista);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Classes";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMensalista;
        private System.Windows.Forms.Button BtnHorista;
        private System.Windows.Forms.Button btnFechar;
    }
}

