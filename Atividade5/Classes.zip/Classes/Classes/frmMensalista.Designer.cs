﻿
namespace Classes
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TxtMatricula = new System.Windows.Forms.TextBox();
            this.TxtNome = new System.Windows.Forms.TextBox();
            this.TxtSalarioMensal = new System.Windows.Forms.TextBox();
            this.TxtDataEntrada = new System.Windows.Forms.TextBox();
            this.btnInstMensalista = new System.Windows.Forms.Button();
            this.btnInstanciarParametros = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.BtnLimpar = new System.Windows.Forms.Button();
            this.btnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Yu Gothic", 14.25F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(178, 118);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Matricula";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Yu Gothic", 14.25F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(178, 157);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Yu Gothic", 14.25F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(178, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(144, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Salario Mensal";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Yu Gothic", 14.25F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(178, 233);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(238, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Data entrada na empresa";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // TxtMatricula
            // 
            this.TxtMatricula.Location = new System.Drawing.Point(489, 118);
            this.TxtMatricula.Name = "TxtMatricula";
            this.TxtMatricula.Size = new System.Drawing.Size(116, 22);
            this.TxtMatricula.TabIndex = 4;
            // 
            // TxtNome
            // 
            this.TxtNome.Location = new System.Drawing.Point(489, 157);
            this.TxtNome.Name = "TxtNome";
            this.TxtNome.Size = new System.Drawing.Size(116, 22);
            this.TxtNome.TabIndex = 5;
            // 
            // TxtSalarioMensal
            // 
            this.TxtSalarioMensal.Location = new System.Drawing.Point(489, 198);
            this.TxtSalarioMensal.Name = "TxtSalarioMensal";
            this.TxtSalarioMensal.Size = new System.Drawing.Size(116, 22);
            this.TxtSalarioMensal.TabIndex = 6;
            // 
            // TxtDataEntrada
            // 
            this.TxtDataEntrada.Location = new System.Drawing.Point(489, 233);
            this.TxtDataEntrada.Name = "TxtDataEntrada";
            this.TxtDataEntrada.Size = new System.Drawing.Size(116, 22);
            this.TxtDataEntrada.TabIndex = 7;
            // 
            // btnInstMensalista
            // 
            this.btnInstMensalista.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.btnInstMensalista.Location = new System.Drawing.Point(170, 296);
            this.btnInstMensalista.Name = "btnInstMensalista";
            this.btnInstMensalista.Size = new System.Drawing.Size(220, 67);
            this.btnInstMensalista.TabIndex = 8;
            this.btnInstMensalista.Text = "Instanciar Mensalista";
            this.btnInstMensalista.UseVisualStyleBackColor = true;
            this.btnInstMensalista.Click += new System.EventHandler(this.btnInstMensalista_Click);
            // 
            // btnInstanciarParametros
            // 
            this.btnInstanciarParametros.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.btnInstanciarParametros.Location = new System.Drawing.Point(427, 296);
            this.btnInstanciarParametros.Name = "btnInstanciarParametros";
            this.btnInstanciarParametros.Size = new System.Drawing.Size(220, 67);
            this.btnInstanciarParametros.TabIndex = 9;
            this.btnInstanciarParametros.Text = "Instanciar Mensalista passando parâmetros";
            this.btnInstanciarParametros.UseVisualStyleBackColor = true;
            this.btnInstanciarParametros.Click += new System.EventHandler(this.btnInstanciarParametros_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Yu Gothic UI", 27.75F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(451, 65);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(196, 50);
            this.label5.TabIndex = 10;
            this.label5.Text = "Mensalista";
            // 
            // BtnLimpar
            // 
            this.BtnLimpar.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.BtnLimpar.Location = new System.Drawing.Point(170, 385);
            this.BtnLimpar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.BtnLimpar.Name = "BtnLimpar";
            this.BtnLimpar.Size = new System.Drawing.Size(220, 43);
            this.BtnLimpar.TabIndex = 15;
            this.BtnLimpar.Text = "Limpar";
            this.BtnLimpar.UseVisualStyleBackColor = true;
            this.BtnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnFechar
            // 
            this.btnFechar.Font = new System.Drawing.Font("Yu Gothic UI", 11.25F);
            this.btnFechar.Location = new System.Drawing.Point(427, 385);
            this.btnFechar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.btnFechar.Name = "btnFechar";
            this.btnFechar.Size = new System.Drawing.Size(220, 43);
            this.btnFechar.TabIndex = 16;
            this.btnFechar.Text = "Fechar";
            this.btnFechar.UseVisualStyleBackColor = true;
            this.btnFechar.Click += new System.EventHandler(this.btnFechar_Click);
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Classes.Properties.Resources.pngtree_ppt_minimalistic_geometric_background_backgroundppt_template_backgroundsimplecool_image_54790;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(794, 440);
            this.Controls.Add(this.btnFechar);
            this.Controls.Add(this.BtnLimpar);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btnInstanciarParametros);
            this.Controls.Add(this.btnInstMensalista);
            this.Controls.Add(this.TxtDataEntrada);
            this.Controls.Add(this.TxtSalarioMensal);
            this.Controls.Add(this.TxtNome);
            this.Controls.Add(this.TxtMatricula);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Segoe UI Symbol", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TxtMatricula;
        private System.Windows.Forms.TextBox TxtNome;
        private System.Windows.Forms.TextBox TxtSalarioMensal;
        private System.Windows.Forms.TextBox TxtDataEntrada;
        private System.Windows.Forms.Button btnInstMensalista;
        private System.Windows.Forms.Button btnInstanciarParametros;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button BtnLimpar;
        private System.Windows.Forms.Button btnFechar;
    }
}